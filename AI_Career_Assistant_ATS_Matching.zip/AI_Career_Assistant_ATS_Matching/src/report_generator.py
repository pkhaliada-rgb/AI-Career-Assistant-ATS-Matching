
from pathlib import Path
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas

ROOT = Path(__file__).resolve().parents[1]

def generate_pdf_report(filename, data):
    path = ROOT / "outputs" / "reports" / filename
    path.parent.mkdir(parents=True, exist_ok=True)
    c = canvas.Canvas(str(path), pagesize=A4)
    width, height = A4
    y = height - 60
    c.setFont("Helvetica-Bold", 16)
    c.drawString(50, y, "AI Career Assistant ATS Report")
    y -= 40
    c.setFont("Helvetica", 11)
    for key, value in data.items():
        if isinstance(value, list):
            value = ", ".join(value)
        c.drawString(50, y, f"{key.replace('_',' ').title()}: {value}")
        y -= 22
        if y < 80:
            c.showPage()
            y = height - 60
            c.setFont("Helvetica", 11)
    c.save()
    return path
