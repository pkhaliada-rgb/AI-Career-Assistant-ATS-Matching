
from pathlib import Path
import joblib
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.ensemble import RandomForestClassifier
from preprocess import preprocess

ROOT = Path(__file__).resolve().parents[1]
MODEL_DIR = ROOT / "models"

def train():
    df = preprocess()
    vectorizer = TfidfVectorizer(stop_words="english", max_features=5000, ngram_range=(1, 2))
    X = vectorizer.fit_transform(df["combined_text"])
    y = df["label"]
    clf = RandomForestClassifier(n_estimators=120, random_state=42)
    clf.fit(X, y)
    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    joblib.dump(vectorizer, MODEL_DIR / "resume_jd_tfidf_vectorizer.pkl")
    joblib.dump(clf, MODEL_DIR / "ats_match_classifier.pkl")
    print("Models saved successfully.")
    print(f"Vectorizer: {MODEL_DIR / 'resume_jd_tfidf_vectorizer.pkl'}")
    print(f"Classifier: {MODEL_DIR / 'ats_match_classifier.pkl'}")

if __name__ == "__main__":
    train()
