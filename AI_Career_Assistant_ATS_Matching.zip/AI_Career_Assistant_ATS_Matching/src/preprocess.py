
from pathlib import Path
import pandas as pd
import re

ROOT = Path(__file__).resolve().parents[1]
RAW_PATH = ROOT / "data" / "raw" / "resume_jd_matching_sample.csv"
PROCESSED_PATH = ROOT / "data" / "processed" / "processed_resume_jd.csv"

def clean_text(text):
    text = str(text).lower()
    text = re.sub(r"[^a-z0-9+#.\s,-]", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text

def preprocess():
    df = pd.read_csv(RAW_PATH)
    df = df.drop_duplicates().fillna("")
    df["resume_clean"] = df["resume_text"].apply(clean_text)
    df["jd_clean"] = df["job_description"].apply(clean_text)
    df["combined_text"] = df["resume_clean"] + " " + df["jd_clean"]
    PROCESSED_PATH.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(PROCESSED_PATH, index=False)
    print(f"Processed dataset saved: {PROCESSED_PATH}")
    return df

if __name__ == "__main__":
    preprocess()
