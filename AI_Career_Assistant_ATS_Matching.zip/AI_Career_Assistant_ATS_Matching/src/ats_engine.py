
from pathlib import Path
import re
import joblib
import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity

ROOT = Path(__file__).resolve().parents[1]
MODEL_DIR = ROOT / "models"
PROCESSED_PATH = ROOT / "data" / "processed" / "processed_resume_jd.csv"

COMMON_SKILLS = [
    "react", "node.js", "node", "express", "mongodb", "javascript", "html", "css",
    "tailwind", "redux", "api", "rest api", "sql", "python", "pandas", "power bi",
    "docker", "jwt", "git", "seo", "content writing", "script writing", "copywriting",
    "generative ai", "data visualization", "statistics", "mern"
]

def clean_text(text):
    text = str(text).lower()
    text = re.sub(r"[^a-z0-9+#.\s,-]", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text

def load_assets():
    if not (MODEL_DIR / "resume_jd_tfidf_vectorizer.pkl").exists():
        from train_model import train
        train()
    vectorizer = joblib.load(MODEL_DIR / "resume_jd_tfidf_vectorizer.pkl")
    clf = joblib.load(MODEL_DIR / "ats_match_classifier.pkl")
    return vectorizer, clf

def extract_skills(text):
    t = clean_text(text)
    found = []
    for skill in COMMON_SKILLS:
        if skill in t:
            found.append(skill.title())
    return sorted(set(found))

def calculate_ats_score(resume_text, jd_text):
    vectorizer, clf = load_assets()
    resume_clean = clean_text(resume_text)
    jd_clean = clean_text(jd_text)
    X_pair = vectorizer.transform([resume_clean + " " + jd_clean])
    label = clf.predict(X_pair)[0]

    r_vec = vectorizer.transform([resume_clean])
    j_vec = vectorizer.transform([jd_clean])
    similarity = float(cosine_similarity(r_vec, j_vec)[0][0])

    resume_skills = set(extract_skills(resume_text))
    jd_skills = set(extract_skills(jd_text))
    skill_score = len(resume_skills & jd_skills) / max(len(jd_skills), 1)

    ats_score = round((0.65 * similarity + 0.35 * skill_score) * 100, 2)
    missing = sorted(jd_skills - resume_skills)
    matched = sorted(resume_skills & jd_skills)

    if ats_score >= 75:
        final_label = "Strong Match"
    elif ats_score >= 50:
        final_label = "Moderate Match"
    else:
        final_label = "Weak Match"

    return {
        "ats_score": ats_score,
        "model_label": label,
        "match_label": final_label,
        "matched_skills": matched,
        "missing_skills": missing,
        "resume_skills": sorted(resume_skills),
        "jd_skills": sorted(jd_skills),
        "similarity_score": round(similarity * 100, 2),
        "skill_score": round(skill_score * 100, 2)
    }

def generate_resume_suggestions(result):
    missing = result.get("missing_skills", [])
    if not missing:
        return "Your resume already matches the major skills required in this job description. Improve impact by adding measurable achievements, project outcomes, and deployment details."
    skills_text = ", ".join(missing)
    return (
        f"Add or strengthen these missing keywords in your resume: {skills_text}. "
        "Include them naturally in your skills section, project descriptions, and experience bullets. "
        "Add measurable outcomes such as performance improvement, API response time, user growth, automation impact, or deployment scale."
    )

def generate_cover_letter(job_title, result):
    matched = ", ".join(result.get("matched_skills", [])) or "relevant technical skills"
    missing = ", ".join(result.get("missing_skills", [])) or "continuous learning"
    return f"""Dear Hiring Manager,

I am excited to apply for the {job_title} position. My experience aligns well with the role through my background in {matched}. I have worked on practical projects involving application development, problem-solving, and user-focused delivery.

I am also actively strengthening my knowledge in {missing}, which will help me contribute more effectively to your team. I am confident that my technical foundation, adaptability, and commitment to continuous improvement make me a strong candidate for this opportunity.

Thank you for considering my application.

Sincerely,
Candidate"""
