
import streamlit as st
from pathlib import Path
from pages import dashboard, ats_matcher, skill_gap, resume_customizer, content_ideas, job_tracker, reports, about

st.set_page_config(
    page_title="AI Career Assistant",
    page_icon="💼",
    layout="wide",
    initial_sidebar_state="expanded"
)

css_path = Path(__file__).parent / "assets" / "style.css"
with open(css_path, "r", encoding="utf-8") as f:
    st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

PAGES = {
    "Dashboard": dashboard.show,
    "ATS Resume-JD Matcher": ats_matcher.show,
    "Skill Gap Analysis": skill_gap.show,
    "Resume Customizer": resume_customizer.show,
    "Content Ideas": content_ideas.show,
    "Job Tracker": job_tracker.show,
    "Reports": reports.show,
    "About Project": about.show,
}

with st.sidebar:
    st.markdown("""
    <div class="sidebar-brand">
        <h2>💼 AI Career Assistant</h2>
        <p>Resume matching, ATS scoring, job support, and content ideas</p>
    </div>
    """, unsafe_allow_html=True)
    st.markdown("<div class='nav-title'>Navigation</div>", unsafe_allow_html=True)
    selected = st.radio("", list(PAGES.keys()), label_visibility="collapsed")
    st.markdown("""
    <div class="sidebar-tip">
        Analyze resume-JD fit, detect missing skills, customize resume points, and generate career content ideas.
    </div>
    """, unsafe_allow_html=True)

PAGES[selected]()
