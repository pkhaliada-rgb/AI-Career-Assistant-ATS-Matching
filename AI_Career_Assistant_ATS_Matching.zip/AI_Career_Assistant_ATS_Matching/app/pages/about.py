
import streamlit as st
from components.ui import hero

def show():
    hero("About Project", "AI Career Assistant for resume-JD matching, ATS scoring, resume customization, and job application support.")
    st.markdown("""
    <div class="content-card">
    <h3>Project Description</h3>
    <p>
    This project demonstrates an AI-powered career assistant for MERN/full-stack developers and job seekers.
    It compares resumes with job descriptions, calculates ATS score, detects missing skills, generates resume suggestions,
    creates cover letter drafts, and tracks job applications.
    </p>

    <h3>Main Objectives</h3>
    <ul>
        <li>Analyze resume and job description similarity.</li>
        <li>Calculate ATS score.</li>
        <li>Detect missing skills and keywords.</li>
        <li>Generate customized resume improvement suggestions.</li>
        <li>Create cover letter drafts.</li>
        <li>Support job application tracking.</li>
        <li>Generate career content ideas and scripts.</li>
    </ul>

    <h3>Technology Stack</h3>
    <p>Python, Streamlit, Pandas, Scikit-Learn, TF-IDF, Cosine Similarity, Random Forest, Plotly, ReportLab.</p>
    </div>
    """, unsafe_allow_html=True)
