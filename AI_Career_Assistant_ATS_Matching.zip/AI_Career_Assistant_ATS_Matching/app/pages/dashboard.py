
import streamlit as st
import plotly.express as px
from components.ui import hero, metric_card
from components.data_loader import load_data, load_history

def show():
    hero("AI Career Assistant Dashboard", "Resume-JD matching, ATS scoring, skill-gap analysis, and career content generation.")
    df = load_data()
    hist = load_history()

    c1, c2, c3, c4 = st.columns(4)
    with c1: metric_card("Resume-JD Records", len(df), "📄")
    with c2: metric_card("Job Roles", df["job_title"].nunique(), "💼")
    with c3: metric_card("Avg Match Score", f'{df["match_score"].mean():.1f}%', "🎯")
    with c4: metric_card("User Analyses", len(hist), "📊")

    left, right = st.columns([1.2, 1])
    with left:
        st.markdown("<div class='content-card'><h3>Job Role Distribution</h3>", unsafe_allow_html=True)
        fig = px.bar(df["job_title"].value_counts().reset_index(), x="job_title", y="count", labels={"job_title":"Job Title","count":"Records"})
        fig.update_layout(height=420, margin=dict(l=20, r=20, t=20, b=20))
        st.plotly_chart(fig, use_container_width=True)
        st.markdown("</div>", unsafe_allow_html=True)
    with right:
        st.markdown("<div class='content-card'><h3>Match Label Distribution</h3>", unsafe_allow_html=True)
        fig = px.pie(df, names="label", hole=0.45)
        fig.update_layout(height=420)
        st.plotly_chart(fig, use_container_width=True)
        st.markdown("</div>", unsafe_allow_html=True)

    st.markdown("""
    <div class="info-strip">
        <h4>Project Workflow</h4>
        <p>Resume Text + Job Description → NLP Cleaning → TF-IDF Similarity → ATS Score → Missing Skills → Resume Suggestions → Cover Letter and Report.</p>
    </div>
    """, unsafe_allow_html=True)
