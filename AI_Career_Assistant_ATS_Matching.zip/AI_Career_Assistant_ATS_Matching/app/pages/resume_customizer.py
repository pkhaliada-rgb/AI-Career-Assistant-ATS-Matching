
import streamlit as st
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[2]
sys.path.append(str(ROOT / "src"))

from components.ui import hero
from ats_engine import calculate_ats_score, generate_resume_suggestions

def show():
    hero("Resume Customizer", "Generate JD-specific resume bullet improvements.")
    resume = st.text_area("Current Resume Summary", value="Developed web applications using React, Node.js, Express, MongoDB, and REST APIs.", height=150)
    jd = st.text_area("Job Description", value="Need MERN developer with React, Node.js, MongoDB, JWT, Docker, API development, Git and deployment experience.", height=150)

    if st.button("Generate Customized Resume Points"):
        result = calculate_ats_score(resume, jd)
        suggestions = generate_resume_suggestions(result)
        st.info(suggestions)

        bullets = [
            "Developed scalable full-stack MERN applications using React, Node.js, Express, and MongoDB.",
            "Implemented REST API modules with authentication, validation, and database integration.",
            "Improved application maintainability using reusable components, structured backend routes, and Git-based workflow.",
        ]
        for skill in result["missing_skills"][:4]:
            bullets.append(f"Strengthened project alignment by adding practical exposure to {skill} based on target job requirements.")

        st.markdown("### Customized Resume Bullets")
        st.text_area("Copy these bullets into your resume", "\n".join([f"- {b}" for b in bullets]), height=260)
