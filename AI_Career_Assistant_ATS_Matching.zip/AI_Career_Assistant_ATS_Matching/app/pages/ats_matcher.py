
import streamlit as st
from pathlib import Path
import sys, pandas as pd
ROOT = Path(__file__).resolve().parents[2]
sys.path.append(str(ROOT / "src"))

from components.ui import hero, metric_card
from ats_engine import calculate_ats_score, generate_resume_suggestions, generate_cover_letter
from report_generator import generate_pdf_report

def show():
    hero("ATS Resume-JD Matcher", "Paste resume and job description to calculate ATS score and skill match.")
    sample_resume = "MERN Stack Developer with experience in React, Node.js, Express, MongoDB, JavaScript, REST API, Git, authentication and dashboard development."
    sample_jd = "We need a MERN developer skilled in React, Node.js, Express, MongoDB, REST API development, JWT authentication, Git, Docker, and deployment."

    job_title = st.text_input("Job Title", value="MERN Stack Developer")
    resume = st.text_area("Resume Text", value=sample_resume, height=170)
    jd = st.text_area("Job Description", value=sample_jd, height=170)

    if st.button("Analyze Resume Match"):
        result = calculate_ats_score(resume, jd)

        c1, c2, c3, c4 = st.columns(4)
        with c1: metric_card("ATS Score", f'{result["ats_score"]}%', "🎯")
        with c2: metric_card("Match Label", result["match_label"], "✅")
        with c3: metric_card("Text Similarity", f'{result["similarity_score"]}%', "🔎")
        with c4: metric_card("Skill Score", f'{result["skill_score"]}%', "🧠")

        st.markdown("### Matched Skills")
        st.success(", ".join(result["matched_skills"]) if result["matched_skills"] else "No matched skills detected.")

        st.markdown("### Missing Skills")
        st.warning(", ".join(result["missing_skills"]) if result["missing_skills"] else "No major missing skills detected.")

        st.markdown("### Resume Improvement Suggestions")
        suggestion = generate_resume_suggestions(result)
        st.info(suggestion)

        st.markdown("### AI Cover Letter Draft")
        cover = generate_cover_letter(job_title, result)
        st.text_area("Generated Cover Letter", cover, height=260)

        history_path = ROOT / "data" / "reports" / "ats_history.csv"
        history_path.parent.mkdir(parents=True, exist_ok=True)
        row = pd.DataFrame([{
            "job_title": job_title,
            "ats_score": result["ats_score"],
            "match_label": result["match_label"],
            "missing_skills": ", ".join(result["missing_skills"])
        }])
        if history_path.exists():
            old = pd.read_csv(history_path)
            row = pd.concat([old, row], ignore_index=True)
        row.to_csv(history_path, index=False)

        pdf = generate_pdf_report("ats_resume_jd_report.pdf", {
            "job_title": job_title,
            **result,
            "suggestions": suggestion
        })
        st.download_button("Download ATS PDF Report", pdf.read_bytes(), "ats_resume_jd_report.pdf", "application/pdf")
