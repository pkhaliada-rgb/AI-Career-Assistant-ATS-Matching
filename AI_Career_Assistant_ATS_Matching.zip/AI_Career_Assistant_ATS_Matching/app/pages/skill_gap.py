
import streamlit as st
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[2]
sys.path.append(str(ROOT / "src"))

from components.ui import hero
from ats_engine import calculate_ats_score

def show():
    hero("Skill Gap Analysis", "Identify missing technical and career skills from a target job description.")
    resume = st.text_area("Resume Text", value="I know React, JavaScript, Node.js, Express, MongoDB and Git.", height=160)
    jd = st.text_area("Target Job Description", value="Looking for MERN developer with React, Node.js, Express, MongoDB, REST API, JWT, Docker, deployment and Git.", height=160)

    if st.button("Find Skill Gaps"):
        result = calculate_ats_score(resume, jd)
        st.markdown("### Skills Present in Resume")
        st.success(", ".join(result["resume_skills"]) if result["resume_skills"] else "No known skills detected.")
        st.markdown("### Skills Required by JD")
        st.info(", ".join(result["jd_skills"]) if result["jd_skills"] else "No known skills detected.")
        st.markdown("### Missing Skills to Add")
        st.warning(", ".join(result["missing_skills"]) if result["missing_skills"] else "No major gap detected.")
