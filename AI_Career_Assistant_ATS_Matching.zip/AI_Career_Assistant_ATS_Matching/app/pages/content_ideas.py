
import streamlit as st
from components.ui import hero

def show():
    hero("AI Content Ideas and Script Generator", "Generate LinkedIn content ideas and short scripts for career growth.")
    role = st.selectbox("Target Role", ["MERN Stack Developer", "Frontend Developer", "Backend Developer", "AI Content Writer", "Data Analyst"])
    topic = st.text_input("Topic", value="How I improved my resume for better ATS score")

    if st.button("Generate Ideas"):
        ideas = [
            f"5 mistakes {role}s make in resumes and how to fix them",
            f"How to tailor your resume for a {role} job description",
            f"Project ideas that help a {role} stand out",
            f"ATS keywords every {role} should include",
            f"My learning roadmap for becoming a job-ready {role}",
        ]
        st.markdown("### Content Ideas")
        for i, idea in enumerate(ideas, 1):
            st.write(f"{i}. {idea}")

        script = f"""Hook: Most candidates apply with the same resume everywhere.

Problem: Recruiters and ATS systems compare your resume against the job description.

Solution: For a {role} role, identify required skills, match them with your resume, and add missing keywords naturally through projects and experience bullets.

CTA: Before applying, check your ATS score and customize your resume for each job."""
        st.markdown("### Short Video Script")
        st.text_area("Generated Script", script, height=220)
