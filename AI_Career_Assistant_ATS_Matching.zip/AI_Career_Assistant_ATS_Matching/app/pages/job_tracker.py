
import streamlit as st
import pandas as pd
from pathlib import Path
from components.ui import hero

ROOT = Path(__file__).resolve().parents[2]
TRACKER = ROOT / "data" / "reports" / "job_tracker.csv"

def show():
    hero("Job Application Tracker", "Track job applications, status, ATS score, and notes.")
    with st.form("job_form"):
        company = st.text_input("Company", "Example Company")
        role = st.text_input("Role", "MERN Stack Developer")
        status = st.selectbox("Status", ["Saved", "Applied", "Interview", "Rejected", "Offer"])
        ats = st.number_input("ATS Score", min_value=0, max_value=100, value=75)
        notes = st.text_area("Notes", "Applied with customized resume.")
        submitted = st.form_submit_button("Add Job")

    if submitted:
        row = pd.DataFrame([{"company": company, "role": role, "status": status, "ats_score": ats, "notes": notes}])
        TRACKER.parent.mkdir(parents=True, exist_ok=True)
        if TRACKER.exists():
            old = pd.read_csv(TRACKER)
            row = pd.concat([old, row], ignore_index=True)
        row.to_csv(TRACKER, index=False)
        st.success("Job added to tracker.")

    if TRACKER.exists():
        df = pd.read_csv(TRACKER)
        st.dataframe(df, use_container_width=True, hide_index=True)
        st.download_button("Download Job Tracker CSV", df.to_csv(index=False), "job_tracker.csv", "text/csv")
    else:
        st.info("No jobs added yet.")
