
import streamlit as st
from pathlib import Path
from components.ui import hero
from components.data_loader import load_history

ROOT = Path(__file__).resolve().parents[2]

def show():
    hero("Reports", "Download ATS history and generated PDF reports.")
    hist = load_history()
    st.markdown("### ATS History")
    st.dataframe(hist, use_container_width=True, hide_index=True)
    st.download_button("Download ATS History CSV", hist.to_csv(index=False), "ats_history.csv", "text/csv")

    st.markdown("### Generated PDF Reports")
    for file in sorted((ROOT / "outputs" / "reports").glob("*.pdf")):
        st.download_button(f"Download {file.name}", file.read_bytes(), file.name, "application/pdf")
