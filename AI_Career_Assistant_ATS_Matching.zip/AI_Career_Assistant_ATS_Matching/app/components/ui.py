
import streamlit as st

def hero(title, subtitle):
    st.markdown(f"""
    <div class="hero-box">
        <span class="hero-badge">AI + MERN Career Assistant</span>
        <h1>{title}</h1>
        <p>{subtitle}</p>
    </div>
    """, unsafe_allow_html=True)

def metric_card(title, value, icon="💼"):
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-icon">{icon}</div>
        <p>{title}</p>
        <h2>{value}</h2>
    </div>
    """, unsafe_allow_html=True)
