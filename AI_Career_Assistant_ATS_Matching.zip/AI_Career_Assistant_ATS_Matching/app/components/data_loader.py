
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
RAW_PATH = ROOT / "data" / "raw" / "resume_jd_matching_sample.csv"
PROCESSED_PATH = ROOT / "data" / "processed" / "processed_resume_jd.csv"
REPORT_PATH = ROOT / "data" / "reports" / "ats_history.csv"

def load_data():
    if PROCESSED_PATH.exists():
        return pd.read_csv(PROCESSED_PATH)
    return pd.read_csv(RAW_PATH)

def load_history():
    if REPORT_PATH.exists():
        return pd.read_csv(REPORT_PATH)
    return pd.DataFrame(columns=["job_title", "ats_score", "match_label", "missing_skills"])
